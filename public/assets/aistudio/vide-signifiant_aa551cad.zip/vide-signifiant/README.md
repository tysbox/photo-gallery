# VIDE SIGNIFIANT — Kyoto Photo Archive

1. `npm install`
2. マスター画像（透かし・落款を焼き込み済み）を `masters/KYOTO-0001.jpg` の形式で配置
   - 比率は 16:9 / 3:4 / 1:1 のいずれか（±2%）。外れる場合はエラーで停止します（自動クロップしません）
3. `scripts/process-images.js` 冒頭の COPYRIGHT / CREATOR を編集し `npm run images`
4. `dist-images/` を R2 へアップロードし、カスタムドメインを `VITE_IMAGE_BASE` に設定
   （ローカル確認だけなら `public/images/` にコピーすれば既定の `/images/` で動作）
5. `public/data/photos.json` / `themes.json` を実データに置き換え（現在はモック3件）
6. `npm run dev` → `npm run deploy`

## 未確認事項（実装時に検証）
- sharp `withExif` で Copyright/Artist が WebP に残ること（`exiftool dist-images/*.webp`）
- 4分割の継ぎ目が各ブラウザ・倍率で見えないこと
- IPTC は sharp では書けないため exiftool を併用
