// masters/ (焼き込み済みJPEG/TIFF) → dist-images/ (WebP: 4分割 + thumbnail)
// 使い方: masters/KYOTO-0001.jpg を置いて `npm run images`
// 出力をR2へ: wrangler r2 object put <bucket>/<file> --file dist-images/<file>
import sharp from "sharp";
import fs from "node:fs/promises";
import path from "node:path";

// ---- 設定 ----------------------------------------------------
const FORMATS = {
  landscape: { w: 1200, h: 676 },  // 16:9
  portrait:  { w: 900,  h: 1200 }, // 3:4
  square:    { w: 960,  h: 960 },  // 1:1
};
const TOLERANCE = 0.02;      // マスターの比率が規定から2%以上ずれたら停止(自動クロップしない)
const QUALITY = 90;
const THUMB_LONG_EDGE = 480;
const COPYRIGHT = "© 作家名 / VIDE SIGNIFIANT. All rights reserved."; // ← 要編集
const CREATOR = "作家名";                                               // ← 要編集
// -------------------------------------------------------------

const IN = "masters", OUT = "dist-images";

function detectFormat(w, h) {
  let best = null;
  for (const [name, f] of Object.entries(FORMATS)) {
    const diff = Math.abs(w / h - f.w / f.h) / (f.w / f.h);
    if (diff <= TOLERANCE && (!best || diff < best.diff)) best = { name, diff };
  }
  return best?.name ?? null;
}

const exif = { IFD0: { Copyright: COPYRIGHT, Artist: CREATOR } };
const webp = (img) => img.webp({ quality: QUALITY, effort: 5 }).withExif(exif);

await fs.mkdir(OUT, { recursive: true });
const files = (await fs.readdir(IN)).filter((f) => /\.(jpe?g|tiff?)$/i.test(f));
const manifest = {};
let failed = 0;

for (const file of files) {
  const id = path.parse(file).name;
  const src = path.join(IN, file);
  const { width, height } = await sharp(src).metadata();
  const format = detectFormat(width, height);
  if (!format) {
    console.error(`✗ ${file}: ${width}x${height} (${(width / height).toFixed(3)}) は 16:9 / 3:4 / 1:1 のいずれにも合いません。マスターを確認してください。`);
    failed++;
    continue;
  }
  const { w, h } = FORMATS[format];
  const base = sharp(src).rotate().resize(w, h, { fit: "fill" }); // 比率は検証済み。クロップはしない
  const buf = await base.toBuffer();
  const hw = w / 2, hh = h / 2; // 全フォーマットで偶数なので割り切れる
  const tiles = { tl: [0, 0], tr: [hw, 0], bl: [0, hh], br: [hw, hh] };
  for (const [key, [left, top]] of Object.entries(tiles)) {
    await webp(sharp(buf).extract({ left, top, width: hw, height: hh }))
      .toFile(path.join(OUT, `${id}_${key}.webp`));
  }
  await webp(sharp(buf).resize({ width: w >= h ? THUMB_LONG_EDGE : undefined, height: w < h ? THUMB_LONG_EDGE : undefined }))
    .toFile(path.join(OUT, `${id}_thumb.webp`));
  manifest[id] = { format, width: w, height: h };
  console.log(`✓ ${id}: ${format} ${w}x${h}`);
}

await fs.writeFile(path.join(OUT, "manifest.json"), JSON.stringify(manifest, null, 2));

// photos.json / themes.json との整合チェック（テーマ内フォーマット統一）
try {
  const photos = JSON.parse(await fs.readFile("public/data/photos.json", "utf8"));
  const themes = JSON.parse(await fs.readFile("public/data/themes.json", "utf8"));
  for (const p of photos) {
    const m = manifest[p.id];
    const t = themes.find((x) => x.id === p.theme);
    if (!t) console.warn(`! ${p.id}: theme "${p.theme}" が themes.json にありません`);
    else if (m && m.format !== t.format) console.warn(`! ${p.id}: ${m.format} ですが theme "${t.id}" は ${t.format} です`);
  }
} catch { /* データ未作成なら無視 */ }

if (failed) process.exitCode = 1;
// 注意: sharp は IPTC を書き込めません。IPTCが必要なら出力後に exiftool で付与してください。
