// 画像の配信元を1か所で管理。R2のカスタムドメインを設定したら VITE_IMAGE_BASE に指定
// 例) VITE_IMAGE_BASE=https://img.example.com/
const BASE = (import.meta.env.VITE_IMAGE_BASE as string | undefined) ?? "/images/";
export const imageUrl = (name: string) => BASE + name;
