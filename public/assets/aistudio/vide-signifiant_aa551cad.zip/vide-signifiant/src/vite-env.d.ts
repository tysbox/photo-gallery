/// <reference types="vite/client" />
declare module "*.module.css" { const c: Record<string, string>; export default c; }
