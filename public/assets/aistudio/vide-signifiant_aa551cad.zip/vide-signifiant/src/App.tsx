import { useEffect, useState } from "react";
import type { Photo, Theme } from "./types";
import { Frame } from "./components/Frame";
import { imageUrl } from "./lib/imageUrl";

// ルーティングは #/ と #/photo/<id> のみ（依存を増やさないためhash方式）
const useHash = () => {
  const [h, setH] = useState(location.hash);
  useEffect(() => { const f = () => setH(location.hash); addEventListener("hashchange", f); return () => removeEventListener("hashchange", f); }, []);
  return h;
};

export function App() {
  const hash = useHash();
  const [photos, setPhotos] = useState<Photo[]>([]);
  const [themes, setThemes] = useState<Theme[]>([]);
  const [tag, setTag] = useState("");

  useEffect(() => {
    Promise.all([fetch("/data/photos.json").then((r) => r.json()), fetch("/data/themes.json").then((r) => r.json())])
      .then(([p, t]) => { setPhotos(p); setThemes(t); });
  }, []);

  const formatOf = (p: Photo) => themes.find((t) => t.id === p.theme)?.format ?? "landscape";
  const tags = [...new Set(photos.flatMap((p) => p.collections))];
  const m = hash.match(/^#\/photo\/(.+)$/);
  const current = m && photos.find((p) => p.id === m[1]);

  return (
    <>
      <header className="head">
        <a href="#/" className="brand">VIDE SIGNIFIANT</a>
        <span className="sub">Kyoto Photo Archive</span>
      </header>
      <main>
        {current ? (
          <section className="detail">
            <Frame photo={current} format={formatOf(current)} />
            <p className="desc">{current.description}</p>
            <p className="meta">{current.location.area}　{current.season}　{current.collections.join(" / ")}</p>
            <a href="#/">一覧へ戻る</a>
          </section>
        ) : (
          <>
            <nav className="tags">
              <button onClick={() => setTag("")} aria-pressed={!tag}>すべて</button>
              {tags.map((t) => <button key={t} onClick={() => setTag(t)} aria-pressed={tag === t}>{t}</button>)}
            </nav>
            {themes.map((t) => {
              const list = photos.filter((p) => p.theme === t.id && (!tag || p.collections.includes(tag)));
              if (!list.length) return null;
              return (
                <section key={t.id} className="theme">
                  <h2>{t.title}</h2>
                  <div className="wall">
                    {list.map((p) => (
                      <a key={p.id} href={`#/photo/${p.id}`} className={`thumb ${t.format}`}>
                        <img src={imageUrl(p.images.thumbnail)} alt={p.title} loading="lazy" draggable={false} />
                        <span>{p.title}</span>
                      </a>
                    ))}
                  </div>
                </section>
              );
            })}
          </>
        )}
      </main>
    </>
  );
}
