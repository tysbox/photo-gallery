export type Format = "landscape" | "portrait" | "square";

export interface Theme { id: string; title: string; format: Format }

export interface Photo {
  id: string;
  title: string;
  theme: string;              // 1作品に1つ。フォーマットはテーマで決まる
  collections: string[];      // 検索・絞り込み用タグ（複数可）
  location: { name: string; area: string };
  date: string;
  season: string;
  description: string;
  images: { thumbnail: string; split: [string, string, string, string] }; // tl, tr, bl, br
}

// 額縁内の表示サイズ(CSS px)。出力画像の半分 = Retinaで2倍密度
export const DISPLAY: Record<Format, { w: number; h: number }> = {
  landscape: { w: 600, h: 338 },
  portrait:  { w: 450, h: 600 },
  square:    { w: 480, h: 480 },
};
