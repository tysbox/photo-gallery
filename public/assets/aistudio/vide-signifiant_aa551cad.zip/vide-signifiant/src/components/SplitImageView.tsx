import type { Photo, Format } from "../types";
import { DISPLAY } from "../types";
import { imageUrl } from "../lib/imageUrl";
import styles from "./SplitImageView.module.css";

// 4枚(左上・右上・左下・右下)をGridで隙間なく結合し、最前面に透明オーバーレイを置く。
// これは「抑止」であり、スクリーンショット等は防げない。主防御は焼き込み済みの透かし/落款と低解像度。
export function SplitImageView({ photo, format }: { photo: Photo; format: Format }) {
  const { w, h } = DISPLAY[format];
  const block = (e: React.SyntheticEvent) => e.preventDefault();
  return (
    <div className={styles.root} style={{ width: `min(${w}px, 100%)`, aspectRatio: `${w} / ${h}` }}
         role="img" aria-label={photo.title}>
      {photo.images.split.map((name, i) => (
        <img key={i} src={imageUrl(name)} alt="" draggable={false} decoding="async" />
      ))}
      <div className={styles.shield} onContextMenu={block} onDragStart={block} />
    </div>
  );
}
