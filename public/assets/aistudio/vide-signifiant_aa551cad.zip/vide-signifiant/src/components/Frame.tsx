import type { Photo, Format } from "../types";
import { SplitImageView } from "./SplitImageView";
import styles from "./Frame.module.css";

export function Frame({ photo, format }: { photo: Photo; format: Format }) {
  return (
    <figure className={styles.frame}>
      <div className={styles.mat}><SplitImageView photo={photo} format={format} /></div>
      <figcaption>
        <span className={styles.title}>{photo.title}</span>
        <span className={styles.meta}>{photo.id}　{photo.location.name}, {photo.date}</span>
      </figcaption>
    </figure>
  );
}
